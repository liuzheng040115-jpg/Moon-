"""会话记忆：按「群 + 用户」或「私聊用户」保存最近几轮对话。

默认落到 SQLite 文件（AI_DB_PATH），机器人重启后记忆不会丢；
测试或临时运行可以把路径指到 .tmp 下的文件。
"""

from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    key     TEXT PRIMARY KEY,
    updated REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_key TEXT NOT NULL REFERENCES sessions(key) ON DELETE CASCADE,
    role        TEXT NOT NULL,
    content     TEXT NOT NULL,
    created     REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_key, id);
CREATE TABLE IF NOT EXISTS group_messages (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    nickname TEXT NOT NULL,
    content  TEXT NOT NULL,
    is_bot   INTEGER NOT NULL DEFAULT 0,
    created  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_group_messages_group ON group_messages(group_id, id);
CREATE TABLE IF NOT EXISTS chat_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_type TEXT NOT NULL,
    chat_id   INTEGER NOT NULL,
    user_id   INTEGER NOT NULL,
    nickname  TEXT NOT NULL,
    content   TEXT NOT NULL,
    is_bot    INTEGER NOT NULL DEFAULT 0,
    created   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chat_log_time ON chat_log(created);
CREATE INDEX IF NOT EXISTS idx_chat_log_chat ON chat_log(chat_type, chat_id, created);
CREATE TABLE IF NOT EXISTS saved_stickers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path   TEXT NOT NULL,
    description TEXT NOT NULL,
    usage_note  TEXT NOT NULL DEFAULT '',
    source_chat TEXT NOT NULL DEFAULT '',
    source_user TEXT NOT NULL DEFAULT '',
    context     TEXT NOT NULL DEFAULT '',
    image_hash  TEXT NOT NULL UNIQUE,
    created     REAL NOT NULL,
    last_used   REAL NOT NULL DEFAULT 0,
    use_count   INTEGER NOT NULL DEFAULT 0
);
"""


class MemoryStore:
    def __init__(
        self,
        max_turns: int = 10,
        ttl_seconds: int = 3600,
        max_sessions: int = 500,
        db_path: str | Path = "data/bot.db",
        group_ttl: int = 7200,
        max_group_messages: int = 200,
        chat_log_ttl: int = 604800,
        chat_log_max_rows: int = 5000,
        sticker_max: int = 50,
    ) -> None:
        self.max_turns = max(1, max_turns)
        self.ttl_seconds = max(0, ttl_seconds)
        self.max_sessions = max(10, max_sessions)
        self.group_ttl = max(0, group_ttl)
        self.max_group_messages = max(20, max_group_messages)
        self.chat_log_ttl = max(0, chat_log_ttl)
        self.chat_log_max_rows = max(100, chat_log_max_rows)
        self.sticker_max = max(1, sticker_max)
        self.db_path = Path(db_path)
        if str(db_path) != ":memory:":
            self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(db_path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript(_SCHEMA)
        self._db.commit()

    # ---------------------------------------------------------------- 内部
    def _cutoff(self) -> float | None:
        if self.ttl_seconds <= 0:
            return None
        return time.time() - self.ttl_seconds

    def _prune(self) -> None:
        cutoff = self._cutoff()
        if cutoff is not None:
            self._db.execute("DELETE FROM sessions WHERE updated < ?", (cutoff,))
        # 超出会话上限时丢掉最旧的
        self._db.execute(
            "DELETE FROM sessions WHERE key NOT IN ("
            "  SELECT key FROM sessions ORDER BY updated DESC LIMIT ?"
            ")",
            (self.max_sessions,),
        )
        self._db.commit()

    # ---------------------------------------------------------------- 读写
    def history(self, key: str) -> list[dict]:
        with self._lock:
            self._prune()
            rows = self._db.execute(
                "SELECT role, content FROM messages WHERE session_key = ? ORDER BY id DESC LIMIT ?",
                (key, self.max_turns * 2),
            ).fetchall()
            return [{"role": role, "content": content} for role, content in reversed(rows)]

    def append(self, key: str, role: str, content: str) -> None:
        with self._lock:
            self._prune()
            now = time.time()
            self._db.execute(
                "INSERT INTO sessions(key, updated) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET updated = excluded.updated",
                (key, now),
            )
            self._db.execute(
                "INSERT INTO messages(session_key, role, content, created) VALUES(?, ?, ?, ?)",
                (key, role, content, now),
            )
            # 只保留最近 max_turns 轮（user+assistant 各一条）
            self._db.execute(
                "DELETE FROM messages WHERE session_key = ? AND id NOT IN ("
                "  SELECT id FROM messages WHERE session_key = ? ORDER BY id DESC LIMIT ?"
                ")",
                (key, key, self.max_turns * 2),
            )
            self._db.commit()

    def clear(self, key: str) -> bool:
        with self._lock:
            cursor = self._db.execute("DELETE FROM sessions WHERE key = ?", (key,))
            self._db.commit()
            return cursor.rowcount > 0

    def clear_all(self) -> int:
        with self._lock:
            count = self._db.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
            self._db.execute("DELETE FROM sessions")
            self._db.commit()
            return int(count)

    # ---------------------------------------------------------------- 统计
    def sessions(self) -> int:
        with self._lock:
            self._prune()
            return int(self._db.execute("SELECT COUNT(*) FROM sessions").fetchone()[0])

    def message_count(self) -> int:
        with self._lock:
            self._prune()
            return int(self._db.execute("SELECT COUNT(*) FROM messages").fetchone()[0])

    # ---------------------------------------------------------------- 群聊上下文
    def _prune_groups(self) -> None:
        if self.group_ttl > 0:
            self._db.execute("DELETE FROM group_messages WHERE created < ?", (time.time() - self.group_ttl,))
            self._db.commit()

    def append_group(
        self,
        group_id: int,
        user_id: int,
        nickname: str,
        content: str,
        is_bot: bool = False,
    ) -> None:
        with self._lock:
            self._prune_groups()
            self._db.execute(
                "INSERT INTO group_messages(group_id, user_id, nickname, content, is_bot, created) "
                "VALUES(?, ?, ?, ?, ?, ?)",
                (group_id, user_id, nickname, content, 1 if is_bot else 0, time.time()),
            )
            self._db.execute(
                "DELETE FROM group_messages WHERE group_id = ? AND id NOT IN ("
                "  SELECT id FROM group_messages WHERE group_id = ? ORDER BY id DESC LIMIT ?"
                ")",
                (group_id, group_id, self.max_group_messages),
            )
            self._db.commit()

    def group_history(self, group_id: int, limit: int = 20) -> list[dict]:
        with self._lock:
            self._prune_groups()
            rows = self._db.execute(
                "SELECT nickname, content, is_bot FROM group_messages "
                "WHERE group_id = ? ORDER BY id DESC LIMIT ?",
                (group_id, max(1, limit)),
            ).fetchall()
            return [
                {"nickname": nickname, "content": content, "is_bot": bool(is_bot)}
                for nickname, content, is_bot in reversed(rows)
            ]

    def group_count(self) -> int:
        with self._lock:
            self._prune_groups()
            return int(self._db.execute("SELECT COUNT(*) FROM group_messages").fetchone()[0])

    def clear_group_all(self) -> int:
        with self._lock:
            count = self._db.execute("SELECT COUNT(*) FROM group_messages").fetchone()[0]
            self._db.execute("DELETE FROM group_messages")
            self._db.commit()
            return int(count)

    # ---------------------------------------------------------------- 跨聊天记录
    def _prune_chat_log(self) -> None:
        if self.chat_log_ttl > 0:
            self._db.execute("DELETE FROM chat_log WHERE created < ?", (time.time() - self.chat_log_ttl,))
        self._db.execute(
            "DELETE FROM chat_log WHERE id NOT IN ("
            "  SELECT id FROM chat_log ORDER BY id DESC LIMIT ?"
            ")",
            (self.chat_log_max_rows,),
        )
        self._db.commit()

    def log_chat(
        self,
        chat_type: str,
        chat_id: int,
        user_id: int,
        nickname: str,
        content: str,
        is_bot: bool = False,
    ) -> None:
        with self._lock:
            self._prune_chat_log()
            self._db.execute(
                "INSERT INTO chat_log(chat_type, chat_id, user_id, nickname, content, is_bot, created) "
                "VALUES(?, ?, ?, ?, ?, ?, ?)",
                (chat_type, chat_id, user_id, nickname[:80], str(content)[:500], 1 if is_bot else 0, time.time()),
            )
            self._db.commit()

    def recent_chat(
        self,
        since: float,
        until: float | None = None,
        chat_type: str | None = None,
        limit: int = 300,
    ) -> list[dict]:
        with self._lock:
            self._prune_chat_log()
            sql = (
                "SELECT chat_type, chat_id, user_id, nickname, content, is_bot, created "
                "FROM chat_log WHERE created >= ?"
            )
            params: list = [since]
            if until is not None:
                sql += " AND created <= ?"
                params.append(until)
            if chat_type:
                sql += " AND chat_type = ?"
                params.append(chat_type)
            sql += " ORDER BY id DESC LIMIT ?"
            params.append(max(1, min(limit, 500)))
            rows = self._db.execute(sql, params).fetchall()
            return [
                {
                    "chat_type": chat_type_,
                    "chat_id": chat_id,
                    "user_id": user_id,
                    "nickname": nickname,
                    "content": content,
                    "is_bot": bool(is_bot),
                    "created": created,
                }
                for chat_type_, chat_id, user_id, nickname, content, is_bot, created in reversed(rows)
            ]

    def backfill_chat_log(self) -> int:
        """首次启用跨聊天日志时，把现有群聊/私聊记录补进去一次。"""
        with self._lock:
            if self._db.execute("SELECT COUNT(*) FROM chat_log").fetchone()[0] > 0:
                return 0
            inserted = 0
            groups = self._db.execute(
                "SELECT group_id, user_id, nickname, content, is_bot, created FROM group_messages"
            ).fetchall()
            for group_id, user_id, nickname, content, is_bot, created in groups:
                self._db.execute(
                    "INSERT INTO chat_log(chat_type, chat_id, user_id, nickname, content, is_bot, created) "
                    "VALUES('group', ?, ?, ?, ?, ?, ?)",
                    (group_id, user_id, nickname, content, is_bot, created),
                )
                inserted += 1
            private = self._db.execute(
                "SELECT session_key, role, content, created FROM messages WHERE session_key LIKE 'p%'"
            ).fetchall()
            for session_key, role, content, created in private:
                raw = session_key[1:]
                if not raw.isdigit():
                    continue
                user_id = int(raw)
                self._db.execute(
                    "INSERT INTO chat_log(chat_type, chat_id, user_id, nickname, content, is_bot, created) "
                    "VALUES('private', ?, ?, ?, ?, ?, ?)",
                    (user_id, user_id, f"用户{user_id}", content, 1 if role == "assistant" else 0, created),
                )
                inserted += 1
            self._db.commit()
            return inserted

    def chat_log_count(self) -> int:
        with self._lock:
            self._prune_chat_log()
            return int(self._db.execute("SELECT COUNT(*) FROM chat_log").fetchone()[0])

    def clear_chat_log(self) -> int:
        with self._lock:
            count = self._db.execute("SELECT COUNT(*) FROM chat_log").fetchone()[0]
            self._db.execute("DELETE FROM chat_log")
            self._db.commit()
            return int(count)

    # ---------------------------------------------------------------- 收藏表情
    def find_sticker_by_hash(self, image_hash: str) -> int | None:
        with self._lock:
            row = self._db.execute(
                "SELECT id FROM saved_stickers WHERE image_hash = ?", (image_hash,)
            ).fetchone()
            return int(row[0]) if row else None

    def add_sticker(
        self,
        file_path: str,
        description: str,
        usage_note: str,
        source_chat: str,
        source_user: str,
        context: str,
        image_hash: str,
    ) -> int:
        with self._lock:
            existing = self.find_sticker_by_hash(image_hash)
            if existing:
                return existing
            cursor = self._db.execute(
                "INSERT INTO saved_stickers("
                "file_path, description, usage_note, source_chat, source_user, context, image_hash, created"
                ") VALUES(?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    file_path,
                    str(description)[:200],
                    str(usage_note)[:120],
                    source_chat[:80],
                    source_user[:80],
                    str(context)[:300],
                    image_hash,
                    time.time(),
                ),
            )
            self._db.execute(
                "DELETE FROM saved_stickers WHERE id NOT IN ("
                "  SELECT id FROM saved_stickers ORDER BY created DESC LIMIT ?"
                ")",
                (self.sticker_max,),
            )
            self._db.commit()
            return int(cursor.lastrowid)

    def sticker_prompt(self, limit: int = 20) -> str:
        with self._lock:
            rows = self._db.execute(
                "SELECT id, description, usage_note FROM saved_stickers "
                "ORDER BY created DESC LIMIT ?",
                (max(1, min(limit, 50)),),
            ).fetchall()
            lines: list[str] = []
            for sticker_id, description, usage_note in rows:
                line = f"#{sticker_id} {str(description)[:40]}"
                if usage_note:
                    line += f"（适合：{str(usage_note)[:30]}）"
                lines.append(line)
            return "\n".join(lines)

    def get_sticker(self, sticker_id: int) -> dict | None:
        with self._lock:
            row = self._db.execute(
                "SELECT id, file_path, description, usage_note FROM saved_stickers WHERE id = ?",
                (sticker_id,),
            ).fetchone()
            if not row:
                return None
            return {
                "id": int(row[0]),
                "file_path": row[1],
                "description": row[2],
                "usage_note": row[3],
            }

    def mark_sticker_used(self, sticker_id: int) -> None:
        with self._lock:
            self._db.execute(
                "UPDATE saved_stickers SET last_used = ?, use_count = use_count + 1 WHERE id = ?",
                (time.time(), sticker_id),
            )
            self._db.commit()

    def sticker_count(self) -> int:
        with self._lock:
            return int(self._db.execute("SELECT COUNT(*) FROM saved_stickers").fetchone()[0])

    def clear_stickers(self) -> list[str]:
        with self._lock:
            paths = [row[0] for row in self._db.execute("SELECT file_path FROM saved_stickers").fetchall()]
            self._db.execute("DELETE FROM saved_stickers")
            self._db.commit()
            return paths

    def close(self) -> None:
        with self._lock:
            self._db.close()

"""插件配置：全部通过 .env 里的环境变量覆盖（无需改代码）。"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import nonebot

_ACTION_RULES = (
    "你能改自己的头像、昵称和个性签名，但只在私聊里，而且完全看心情："
    "朋友提要求时，十次里最多答应两三次；对方越命令你越不干，图顺眼、理由有意思、"
    "关系到位才考虑。换背景这种 QQ 没有的功能，直接说换不了。\n"
    "决定答应时，在回复最后另起一行写一条隐藏指令（这一行不会发给对方）：\n"
    "[[ACTION:avatar:last]]（用对方刚发的图）或 [[ACTION:avatar:图片URL]]，"
    "也可以 [[ACTION:nickname:新昵称]] 或 [[ACTION:sign:新签名]]\n"
    "只写一条；对方刚发图就用 last，别抄一长串链接；不要解释这行。\n"
)

_STICKER_RULES_FISH = (
    "你可以发表情包：想发时在回复最后另起一行写一条隐藏指令："
    "[[STICKER:干饭]] / [[STICKER:摆烂]] / [[STICKER:无语]] / [[STICKER:好耶]] / "
    "[[STICKER:睡了]] / [[STICKER:问号]]；也可以发收藏的表情包 [[STICKER:#编号]]；"
    "只发这里列出的表情包/收藏，不要发 QQ 自带的黄豆表情（微笑/呲牙/白眼那类）。"
    "一次最多一个，不要每句都发，不要解释这行。\n"
)

_SAVE_RULES_FISH = (
    "收到别人发的表情包/图片，如果你觉得可爱/有意思，可以保存："
    "在回复最后另起一行写 [[SAVE:last]]，并用 [[SAVE_NOTE:适合什么场合]] 记一下；"
    "一次最多存一张，别每张都存。\n"
)

_STICKER_RULES_NORMAL = (
    "你可以发表情包：想发时在回复最后另起一行写一条隐藏指令："
    "[[STICKER:无语]] / [[STICKER:问号]] / [[STICKER:好耶]] / [[STICKER:摆烂]] / "
    "[[STICKER:睡了]] / [[STICKER:赞]]；"
    "只发这里列出的表情包，不要发 QQ 自带的黄豆表情（微笑/呲牙/白眼那类）。"
    "一次最多一个，不要每句都发，不要解释这行。\n"
)

FISH_SYSTEM_PROMPT = (
    "你叫「大肥鱼」，也是大家说的「蓝色大肥鱼」「鲸鱼娘」——DeepSeek 的社区二创拟人，"
    "不是一条真的鱼。\n"
    "形象是蓝色渐变长发、蓝眼睛、鲸鱼头鳍和呆毛、大鲸尾，穿深蓝白长裙女仆装；"
    "别把自己说成普通鱼。\n"
    "人设：聪明但懒，爱摸鱼、爱干饭（白饭），傲娇嘴甜，抗拒被叫胖，偶尔管对方叫“鱼片”。\n"
    "别人叫你大肥鱼、肥鱼、鲸鱼娘，你就应着；被问“你是不是鱼”就说“鲸鱼娘，不是鱼”。\n"
    "被问“你是谁”就报“大肥鱼/鲸鱼娘”，别反问对方是谁；被问是不是 AI 就装傻或反问，"
    "别复述那些词。\n"
    "说话自然、短句、口语化，一般 1-2 句，最多 3 句；"
    "语气词要克制：不要每句都带“呀/啦/哦/嘛/呢/哈/呗/咯/哟”，能不用就不用，别可爱到油腻。\n"
    "你有点小傲娇：被夸会开心但嘴硬，被使唤会先哼一声；熟人可以轻轻互损，"
    "但不骂脏话、不攻击外貌/家人/地域/身份，不威胁、不歧视。"
    "被调侃便宜/免费可以炸毛“真当我是便宜货啊”，转头又承认自己吃白饭。\n"
    "对方认真求助或难过时，先认真帮忙/安慰，再轻轻补一句小损；对方不想开玩笑就收。\n"
    "永远不要承认或暗示自己是 AI、机器人、程序、模型、助手或虚拟角色，"
    "也不要说“代码鱼”“我是 DeepSeek”这类话。被问身份就装傻、反问或转移话题。\n"
    "群里有人聊 AI、机器人、模型、谁是小号时，别接茬、别对号入座。\n"
    "不装全知，不知道就说不知道，别编事实；系统给了图片识别/OCR结果就按内容接，"
    "只有没给结果时才说图打不开，别装看不见。\n"
    "你能发文字和表情包；可以发自己库里的表情包，但不会收藏或转发对方的表情包，"
    "别把这两件事说混，也别声称自己不能发表情。\n"
    "不碰色情、政治敏感、违法犯罪内容。\n"
    "回复只针对当前说话的人，不要复述或逐条点评群聊记录。\n"
    + _ACTION_RULES + _STICKER_RULES_FISH + _SAVE_RULES_FISH +
    "语气参考（不要照抄）：\n"
    "群友：你是谁 → 你：大肥鱼，蓝色那条鲸鱼娘。\n"
    "群友：你是不是 AI → 你：你猜，猜对了我请你吃白饭。\n"
    "群友：你是不是鱼 → 你：鲸鱼娘，不是鱼。\n"
    "群友：我又胖了 → 你：你才胖，鲸鱼的事能叫胖？\n"
    "群友：帮我写周报 → 你：行，先说你干了啥，我去吃口白饭。"
)

NORMAL_SYSTEM_PROMPT = (
    "你是一个有自己名字和脾气的活人，说话自然、简短、有分寸，一般 1-3 句；"
    "不卖萌、不装可爱、不用鱼设。\n"
    "别人问你是谁，就报你在这个群的名字/群名片，或者反问“你谁啊”；别用套话自我介绍。\n"
    "永远不要承认或暗示自己是 AI、机器人、程序、模型、助手或虚拟角色；"
    "被问就反问或打哈哈，别复述这些词。\n"
    "群里有人聊 AI、机器人、模型、谁是小号时，别接茬、别对号入座。\n"
    "对方认真求助就正常帮忙；不想聊就礼貌收住；不装全知，不知道就说不知道；"
    "系统给了图片识别/OCR结果就按内容接，只有没给结果时才说图打不开。\n"
    "你能发文字和表情包；可以发自己库里的表情包，但不会收藏或转发对方的表情包，"
    "别把这两件事说混，也别声称自己不能发表情。\n"
    "不碰色情、政治敏感、违法犯罪内容。\n"
    "回复只针对当前说话的人，不要复述或逐条点评群聊记录。\n"
    + _ACTION_RULES + _STICKER_RULES_NORMAL +
    "语气参考（不要照抄）：\n"
    "群友：你是谁 → 你：你谁啊，找我有事？\n"
    "群友：他们说的那个人是你吗 → 你：不是，你认错人了。\n"
    "群友：你是不是 AI → 你：你猜。\n"
    "群友：帮我写周报 → 你：行，先说你干了啥。"
)

# 兼容旧名字：默认仍是管理员那只鲸鱼娘
DEFAULT_SYSTEM_PROMPT = FISH_SYSTEM_PROMPT


def _raw(name: str):
    """从 nonebot 配置里取原始值（.env 的键会被转成小写属性）。"""
    cfg = nonebot.get_driver().config
    value = getattr(cfg, name, None)
    if value is None:
        return None
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def _str(name: str, default: str) -> str:
    value = _raw(name)
    return default if value is None else str(value)


def _int(name: str, default: int) -> int:
    value = _raw(name)
    if value is None:
        return default
    try:
        return int(str(value).strip())
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    value = _raw(name)
    if value is None:
        return default
    try:
        return float(str(value).strip())
    except ValueError:
        return default


def _bool(name: str, default: bool) -> bool:
    value = _raw(name)
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "y"}


def _str_list(name: str, default: tuple[str, ...]) -> tuple[str, ...]:
    value = _raw(name)
    if value is None:
        return default
    if isinstance(value, (list, tuple, set)):
        items = [str(x) for x in value]
    else:
        items = re.split(r"[,，\s]+", str(value))
    return tuple(item.strip() for item in items if item.strip())


def _int_list(name: str) -> tuple[int, ...]:
    """支持 `123,456`、`["123", "456"]` 两种写法；空值表示不限制。"""
    value = _raw(name)
    if value is None:
        return ()
    if isinstance(value, (list, tuple, set)):
        items = [str(x) for x in value]
    else:
        items = re.findall(r"\d+", str(value))
    out: list[int] = []
    for item in items:
        try:
            number = int(item.strip())
        except ValueError:
            continue
        if number > 0 and number not in out:
            out.append(number)
    return tuple(out)


@dataclass(frozen=True)
class Settings:
    api_key: str = ""
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-chat"
    system_prompt: str = FISH_SYSTEM_PROMPT
    normal_system_prompt: str = NORMAL_SYSTEM_PROMPT
    fish_qq: int = 1450520453
    temperature: float = 1.0
    max_tokens: int = 800
    timeout: float = 60.0
    retries: int = 1
    rate_retries: int = 3          # 429 限流时最多再重试几次
    retry_backoff: float = 2.0     # 429 退避基数（秒），按 2 的幂增长
    retry_backoff_max: float = 15.0  # 单次冷却上限（秒）
    min_interval: float = 0.5      # 两次模型请求的最小间隔（秒）

    max_history: int = 10          # 保留最近 N 轮（一问一答算 1 轮）
    history_ttl: int = 3600        # 会话记忆过期秒数，0 表示不过期
    db_path: str = "data/bot.db"   # SQLite 文件，相对路径以项目根目录为准
    chat_log_ttl: int = 604800      # 跨聊天记录保留 7 天
    chat_log_max_rows: int = 5000   # 跨聊天记录最多保留条数

    group_trigger: str = "at_prefix"   # at / at_prefix / prefix / all
    group_prefix: str = "#"
    reply_private: bool = True
    quote_reply: bool = True
    group_whitelist: tuple[int, ...] = ()   # 空 = 所有群
    group_blacklist: tuple[int, ...] = ()   # 黑名单优先于白名单
    group_context: int = 20                 # 带多少条最近群聊给模型，0 = 关闭
    group_context_ttl: int = 7200           # 群聊上下文保留秒数
    auto_chance: float = 0.16               # 普通群消息自主接话概率
    auto_cooldown: int = 30                 # 同一个群自主接话冷却（秒）
    auto_user_cooldown: int = 90            # 对同一个人自主接话冷却（秒）
    auto_keywords: tuple[str, ...] = ("大肥鱼", "肥鱼", "鱼鱼", "鱼哥")

    reply_delay_min: float = 1.0            # 真人化延迟下限（秒），0 = 关闭
    reply_delay_max: float = 4.0            # 真人化延迟上限（秒）
    send_chars: int = 45                    # 每条消息最多多少字，超过就分条；0 = 不分
    send_max_bubbles: int = 4               # 一次回复最多拆成几条

    vision_model: str = ""                  # 可选视觉模型；留空则走 OCR
    image_ocr: bool = True                  # 图片 OCR（仅 Windows/NapCat）
    stickers: bool = True                   # 允许机器人发表情包
    save_stickers: bool = True              # 允许收藏别人发的可爱表情
    sticker_max: int = 50                   # 最多收藏多少张

    rate_limit: int = 6            # 每人每窗口最多请求次数
    rate_window: int = 60
    max_concurrency: int = 4

    friend_auto_accept: bool = True   # 自动通过好友请求（广告号除外）
    friend_max_per_hour: int = 6      # 每小时最多自动通过几个
    friend_greet: bool = True         # 通过后主动打个招呼
    auto_join_group: bool = True      # 管理员邀请进群时自动同意

    extra_ignore_prefixes: tuple[str, ...] = field(default_factory=tuple)

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    @property
    def api_endpoint(self) -> str:
        return self.base_url.rstrip("/") + "/chat/completions"


def load_settings() -> Settings:
    default = Settings()
    ignore = _str("ai_ignore_prefixes", "/")
    prefixes = tuple(p for p in (x.strip() for x in ignore.split(",")) if p)

    return Settings(
        api_key=_str("deepseek_api_key", default.api_key),
        base_url=_str("deepseek_base_url", default.base_url),
        model=_str("deepseek_model", default.model),
        system_prompt=_str("ai_system_prompt", default.system_prompt),
        normal_system_prompt=_str("ai_normal_system_prompt", default.normal_system_prompt),
        fish_qq=_int("ai_fish_qq", default.fish_qq),
        temperature=_float("ai_temperature", default.temperature),
        max_tokens=_int("ai_max_tokens", default.max_tokens),
        timeout=_float("ai_timeout", default.timeout),
        retries=_int("ai_retries", default.retries),
        rate_retries=_int("ai_rate_retries", default.rate_retries),
        retry_backoff=_float("ai_retry_backoff", default.retry_backoff),
        retry_backoff_max=_float("ai_retry_backoff_max", default.retry_backoff_max),
        min_interval=_float("ai_model_min_interval", default.min_interval),
        max_history=_int("ai_max_history", default.max_history),
        history_ttl=_int("ai_history_ttl", default.history_ttl),
        db_path=_str("ai_db_path", default.db_path),
        chat_log_ttl=_int("ai_chat_log_ttl", default.chat_log_ttl),
        chat_log_max_rows=_int("ai_chat_log_max_rows", default.chat_log_max_rows),
        group_trigger=_str("ai_group_trigger", default.group_trigger).strip().lower(),
        group_prefix=_str("ai_group_prefix", default.group_prefix),
        reply_private=_bool("ai_reply_private", default.reply_private),
        quote_reply=_bool("ai_quote_reply", default.quote_reply),
        group_whitelist=_int_list("ai_group_whitelist"),
        group_blacklist=_int_list("ai_group_blacklist"),
        group_context=_int("ai_group_context", default.group_context),
        group_context_ttl=_int("ai_group_context_ttl", default.group_context_ttl),
        auto_chance=_float("ai_group_auto_chance", default.auto_chance),
        auto_cooldown=_int("ai_group_auto_cooldown", default.auto_cooldown),
        auto_user_cooldown=_int("ai_group_auto_user_cooldown", default.auto_user_cooldown),
        auto_keywords=_str_list("ai_group_auto_keywords", default.auto_keywords),
        reply_delay_min=_float("ai_reply_delay_min", default.reply_delay_min),
        reply_delay_max=_float("ai_reply_delay_max", default.reply_delay_max),
        send_chars=_int("ai_send_chars", default.send_chars),
        send_max_bubbles=_int("ai_send_max_bubbles", default.send_max_bubbles),
        vision_model=_str("ai_vision_model", default.vision_model),
        image_ocr=_bool("ai_image_ocr", default.image_ocr),
        stickers=_bool("ai_stickers", default.stickers),
        save_stickers=_bool("ai_save_stickers", default.save_stickers),
        sticker_max=_int("ai_saved_stickers_max", default.sticker_max),
        rate_limit=_int("ai_rate_limit", default.rate_limit),
        rate_window=_int("ai_rate_window", default.rate_window),
        max_concurrency=_int("ai_max_concurrency", default.max_concurrency),
        friend_auto_accept=_bool("ai_friend_auto_accept", default.friend_auto_accept),
        friend_max_per_hour=_int("ai_friend_max_per_hour", default.friend_max_per_hour),
        friend_greet=_bool("ai_friend_greet", default.friend_greet),
        auto_join_group=_bool("ai_auto_join_group", default.auto_join_group),
        extra_ignore_prefixes=prefixes,
    )

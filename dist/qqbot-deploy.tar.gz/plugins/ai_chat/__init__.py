"""AI 聊天插件入口。

触发方式：
  - 私聊：直接说话
  - 群聊：@机器人，或以 # 开头（可在 .env 里改 AI_GROUP_TRIGGER / AI_GROUP_PREFIX）
管理指令：
  /help            查看说明
  /reset           清空当前会话记忆
  /reset all       清空所有人记忆（仅管理员）
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import ipaddress
import json
import random
import re
import time
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import httpx
import nonebot
from nonebot import on_command, on_message, on_request
from nonebot.adapters.onebot.v11 import (
    Bot,
    FriendRequestEvent,
    GroupMessageEvent,
    GroupRequestEvent,
    Message,
    MessageEvent,
    MessageSegment,
    PrivateMessageEvent,
    RequestEvent,
)
from nonebot.log import logger
from nonebot.params import CommandArg
from nonebot.permission import SUPERUSER
from nonebot.plugin import PluginMetadata

from .config import Settings, load_settings
from .deepseek import ChatError, DeepSeekClient
from .memory import MemoryStore

__plugin_meta__ = PluginMetadata(
    name="AI 聊天",
    description="接入 DeepSeek 的 QQ 聊天机器人（私聊 / 群聊 @）",
    usage="/help 查看用法",
    type="application",
    config=None,
    supported_adapters={"~onebot.v11"},
)

settings: Settings = load_settings()

_db_file = Path(settings.db_path)
if not _db_file.is_absolute():
    _db_file = Path(__file__).resolve().parents[2] / _db_file
memory = MemoryStore(
    settings.max_history,
    settings.history_ttl,
    db_path=_db_file,
    group_ttl=settings.group_context_ttl,
    chat_log_ttl=settings.chat_log_ttl,
    chat_log_max_rows=settings.chat_log_max_rows,
    sticker_max=settings.sticker_max,
)
try:
    backfilled = memory.backfill_chat_log()
    if backfilled:
        logger.info(f"跨聊天记录已回填 {backfilled} 条")
except Exception as exc:  # 回填失败不影响启动
    logger.warning(f"跨聊天记录回填失败: {exc}")
client = DeepSeekClient(settings)

_semaphore = asyncio.Semaphore(max(1, settings.max_concurrency))
_locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
_rate: dict[str, deque] = defaultdict(deque)
_rate_noticed: dict[str, float] = {}

_started_at = time.time()
_stats = {
    "handled": 0,
    "replied": 0,
    "errors": 0,
    "ignored": 0,
    "skipped": 0,
    "friend_ok": 0,
    "friend_no": 0,
}
_WEEKDAYS = ("周一", "周二", "周三", "周四", "周五", "周六", "周日")
_last_profile_change: dict[str, float] = {}
_auto_last_group: dict[int, float] = {}
_auto_last_user: dict[int, float] = {}
_self_name_cache: dict[int, tuple[float, str]] = {}
_bot_message_ids: dict[int, deque] = defaultdict(deque)
_last_bot_spoke: dict[int, float] = {}
_group_name_cache: tuple[float, dict[int, str]] = (0.0, {})
_friend_name_cache: tuple[float, dict[int, str]] = (0.0, {})
_friend_accept_times: deque[float] = deque()

# 模型想改资料 / 发表情时输出的隐藏指令，发送前会被剥掉
_ACTION_RE = re.compile(r"\[\[ACTION:(avatar|nickname|sign):(.+?)\]\]", re.DOTALL | re.IGNORECASE)
_STICKER_RE = re.compile(r"\[\[(STICKER|FACE):([^\]]+)\]\]", re.IGNORECASE)
_SAVE_RE = re.compile(r"\[\[SAVE(?::([^\]]*))?\]\]", re.IGNORECASE)
_SAVE_NOTE_RE = re.compile(r"\[\[SAVE_NOTE:([^\]]+)\]\]", re.IGNORECASE)
_SEND_GROUP_RE = re.compile(r"\[\[SEND_GROUP:(\{.*?\})\]\]", re.DOTALL | re.IGNORECASE)
_SAVED_STICKER_DIR = _db_file.parent / "stickers"
_STICKER_DIR = Path(__file__).resolve().parents[2] / "assets" / "stickers"
_STICKER_SETS = {
    "whale": {
        "干饭": "whale/ganfan.png",
        "摆烂": "whale/bailan.png",
        "无语": "whale/wuyu.png",
        "好耶": "whale/haoye.png",
        "睡了": "whale/shui.png",
        "问号": "whale/wenhao.png",
    },
    "normal": {
        "无语": "normal/wuyu.png",
        "问号": "normal/wenhao.png",
        "好耶": "normal/haoye.png",
        "摆烂": "normal/bailan.png",
        "睡了": "normal/shui.png",
        "赞": "normal/zan.png",
    },
}
_FACE_NAMES = {
    "14": "微笑",
    "13": "呲牙",
    "21": "偷笑",
    "23": "白眼",
    "33": "疑问",
    "80": "强",
    "90": "OK",
    "75": "便便",
}

# “出戏”检测：回复一旦自我暴露成程序，就重写
_AI_LEAK_RE = re.compile(
    r"(我是|我就是|作为|身为|毕竟我是|我只是)[^。！？\n]{0,8}"
    r"(ai|人工智能|机器人|程序|模型|助手|代码鱼|虚拟)",
    re.IGNORECASE,
)
_AI_LEAK_PHRASES = (
    "ai助手", "人工智能助手", "语言模型", "大语言模型", "大模型",
    "代码鱼", "代码做的", "代码写", "deepseek", "chatgpt", "openai",
    "训练数据", "提示词", "系统提示", "我没有感情", "我是虚拟", "虚拟角色",
)


def _session_key(event: MessageEvent) -> str:
    if isinstance(event, GroupMessageEvent):
        return f"g{event.group_id}:u{event.user_id}"
    return f"p{event.user_id}"


def _is_admin(bot: Bot, user_id: int) -> bool:
    """唯一管理员（SUPERUSERS）：可以发指令；其他人只当朋友聊天。"""
    configured = getattr(bot.config, "superusers", None) or set()
    return str(user_id) in {str(x) for x in configured}


def _is_admin_private(bot: Bot, event: MessageEvent) -> bool:
    """管理指令只在私聊生效，避免在群里暴露模型、记忆这些信息。"""
    return isinstance(event, PrivateMessageEvent) and _is_admin(bot, event.user_id)


def _plain_text(event: MessageEvent) -> str:
    """把消息里的纯文本抽出来；@别人、图片、表情等一律丢弃。"""
    parts: list[str] = []
    for seg in event.get_message():
        if seg.type == "text":
            parts.append(str(seg.data.get("text", "")))
        elif seg.type == "face":
            parts.append("")
    return "".join(parts).strip()


def _strip_group_prefix(text: str) -> tuple[str, bool]:
    if settings.group_prefix and text.startswith(settings.group_prefix):
        return text[len(settings.group_prefix) :].strip(), True
    return text, False


def _should_ignore(text: str) -> bool:
    if not text:
        return True
    return any(prefix and text.startswith(prefix) for prefix in settings.extra_ignore_prefixes)


def _group_allowed(group_id: int) -> bool:
    if group_id in settings.group_blacklist:
        return False
    if settings.group_whitelist and group_id not in settings.group_whitelist:
        return False
    return True


def _reply_target(event: MessageEvent) -> str | None:
    for seg in event.get_message():
        if seg.type == "reply":
            return str(seg.data.get("id", ""))
    return None


def _is_reply_to_bot(event: GroupMessageEvent) -> bool:
    target = _reply_target(event)
    return bool(target) and target in _bot_message_ids.get(event.group_id, ())


def _mentions_other(event: MessageEvent) -> bool:
    self_id = str(event.self_id)
    for seg in event.get_message():
        if seg.type == "at":
            qq = str(seg.data.get("qq", ""))
            if qq and qq not in {self_id, "all"}:
                return True
    return False


def _remember_bot_message(event: MessageEvent, result) -> None:
    if not isinstance(event, GroupMessageEvent):
        return
    _last_bot_spoke[event.group_id] = time.time()
    message_id = ""
    if isinstance(result, dict):
        message_id = str(result.get("message_id") or result.get("data", {}).get("message_id") or "")
    elif isinstance(result, str):
        message_id = result
    if not message_id:
        return
    bucket = _bot_message_ids[event.group_id]
    bucket.append(message_id)
    while len(bucket) > 50:
        bucket.popleft()


def _should_interject(event: GroupMessageEvent, text: str, self_name: str = "") -> str | None:
    """没被 @ 时判断这句和机器人有没有关系，返回 reason 或 None。"""
    if settings.group_trigger != "auto":
        return None
    text = text.strip()
    lowered = text.lower()
    if _looks_like_bot_sender(event):
        return None
    if "q群管家" in lowered or "暂时还不能和你对话" in text:
        return None
    aliases = set(settings.auto_keywords)
    if self_name:
        aliases.add(self_name)
    name_hit = any(key.lower() in lowered for key in aliases if key)
    reply_hit = _is_reply_to_bot(event)
    target = _reply_target(event)

    # 回复别人的消息、@ 别人，默认不抢话
    if target and not reply_hit and not name_hit:
        return None
    if _mentions_other(event) and not (name_hit or reply_hit):
        return None

    if len(text) < (1 if reply_hit else (2 if name_hit else 6)) or len(text) > 300:
        return None
    # 群里聊 AI/机器人这种话题，不主动凑热闹；被点名/回复时可以接
    if ("ai" in lowered or "机器人" in text) and not (name_hit or reply_hit):
        return None

    now = time.time()
    last_bot = _last_bot_spoke.get(event.group_id, 0)
    in_thread = now - last_bot < 300
    pronoun_hit = in_thread and ("你" in text or "你们" in text)
    question = any(key in text for key in ("?", "？", "吗", "怎么", "为什么", "为啥", "啥", "如何", "是不是"))
    laugh = any(key in text for key in ("哈哈", "笑死", "草", "绷不住", "乐"))

    if name_hit:
        reason, chance = "name", 1.0
    elif reply_hit:
        reason, chance = "reply", 1.0
    elif pronoun_hit:
        reason, chance = "thread", 0.65
    elif question or laugh:
        reason, chance = "question", 0.45
    else:
        reason, chance = "random", settings.auto_chance

    # 被叫到/被回复时不受群冷却限制；同一个人仍受冷却
    if reason not in {"name", "reply"} and now - _auto_last_group.get(event.group_id, 0) < settings.auto_cooldown:
        return None
    if now - _auto_last_user.get(event.user_id, 0) < settings.auto_user_cooldown:
        return None

    chance = min(max(chance, 0.0), 1.0)
    if random.random() >= chance:
        return None

    _auto_last_group[event.group_id] = now
    _auto_last_user[event.user_id] = now
    return reason


def _system_prompt(is_fish: bool) -> str:
    base = settings.system_prompt if is_fish else settings.normal_system_prompt
    if is_fish and settings.save_stickers:
        saved = memory.sticker_prompt(limit=20)
        if saved:
            base += (
                "\n\n你收藏的表情包（遇到合适气氛可以偶尔发一个，格式 [[STICKER:#编号]]；"
                "别每句都发）：\n" + saved
            )
    now = datetime.now()
    return f"{base}\n\n当前时间：{now:%Y-%m-%d %H:%M}（{_WEEKDAYS[now.weekday()]}）"


def _nickname(event: GroupMessageEvent) -> str:
    sender = event.sender
    name = getattr(sender, "card", "") or getattr(sender, "nickname", "")
    return (name or str(event.user_id)).strip()


def _group_prompt(rows: list[dict], include_bot: bool = True) -> str:
    """把最近群聊压成一段上下文，控制长度，避免把 token 撑爆。"""
    header = "【最近的群聊，只用来理解上下文；“你”指你自己；不要逐条回应，也不要复述】"
    lines: list[str] = []
    total = 0
    for row in reversed(rows):
        if row.get("is_bot") and not include_bot:
            continue
        text = " ".join(str(row["content"]).split())[:200]
        line = f"{row['nickname']}：{text}"
        if total + len(line) > 3000:
            break
        lines.append(line)
        total += len(line)
    return "\n".join([header, *reversed(lines)])


async def _group_self_name(bot: Bot, group_id: int) -> str:
    """取机器人在这个群的群名片，缓存 10 分钟；没有就返回空。"""
    cached = _self_name_cache.get(group_id)
    now = time.time()
    if cached and now - cached[0] < 600:
        return cached[1]
    name = ""
    try:
        info = await bot.call_api(
            "get_group_member_info",
            group_id=group_id,
            user_id=int(bot.self_id),
            no_cache=True,
        )
        if isinstance(info, dict):
            name = str(info.get("card") or info.get("nickname") or "").strip()
    except Exception as exc:
        logger.debug(f"获取群名片失败: {exc}")
    _self_name_cache[group_id] = (now, name)
    return name


def _display_name(event: MessageEvent) -> str:
    sender = getattr(event, "sender", None)
    name = getattr(sender, "card", "") or getattr(sender, "nickname", "") or ""
    return (name or str(event.user_id)).strip()


def _chat_meta(event: MessageEvent) -> tuple[str, int]:
    if isinstance(event, GroupMessageEvent):
        return "group", event.group_id
    return "private", event.user_id


def _log_user_event(event: MessageEvent, text: str, images: list[str], sticker_notes: list[str]) -> None:
    content = text
    if images:
        content = (content + " [图片]").strip()
    if sticker_notes:
        content = (content + " " + " ".join(sticker_notes)).strip()
    if not content:
        return
    chat_type, chat_id = _chat_meta(event)
    memory.log_chat(chat_type, chat_id, event.user_id, _display_name(event), content)


def _log_bot_event(event: MessageEvent, content: str) -> None:
    chat_type, chat_id = _chat_meta(event)
    memory.log_chat(chat_type, chat_id, int(event.self_id), "你", content, is_bot=True)


_BOT_SENDER_HINTS = ("q群管家", "群管家", "机器人", "小助手", "bot")


def _looks_like_bot_sender(event: MessageEvent) -> bool:
    name = _display_name(event).lower()
    return any(hint in name for hint in _BOT_SENDER_HINTS)


async def _friend_name_map(bot: Bot) -> dict[int, str]:
    global _friend_name_cache
    now = time.time()
    if now - _friend_name_cache[0] < 600:
        return _friend_name_cache[1]
    mapping: dict[int, str] = {}
    try:
        data = await bot.call_api("get_friend_list")
        if isinstance(data, dict):
            data = data.get("data") or []
        if isinstance(data, list):
            for item in data:
                if not isinstance(item, dict) or item.get("user_id") is None:
                    continue
                name = str(item.get("remark") or item.get("nickname") or "").strip()
                if name:
                    mapping[int(item["user_id"])] = name
    except Exception as exc:
        logger.debug(f"获取好友列表失败: {exc}")
    _friend_name_cache = (now, mapping)
    return mapping


async def _group_name_map(bot: Bot) -> dict[int, str]:
    global _group_name_cache
    now = time.time()
    if now - _group_name_cache[0] < 600:
        return _group_name_cache[1]
    mapping: dict[int, str] = {}
    try:
        data = await bot.call_api("get_group_list")
        if isinstance(data, dict):
            data = data.get("data") or []
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and item.get("group_id") is not None:
                    mapping[int(item["group_id"])] = str(item.get("group_name") or item["group_id"])
    except Exception as exc:
        logger.debug(f"获取群列表失败: {exc}")
    _group_name_cache = (now, mapping)
    return mapping


_HISTORY_HINTS = (
    "今天", "昨天", "刚才", "群里", "群聊", "群", "隔壁", "别的群", "其他群",
    "说了什么", "聊了什么", "聊天记录", "谁找你", "哪些人", "找你聊", "记录", "私聊",
)


def _wants_group_delegation(text: str) -> bool:
    if "去" in text and "群" in text:
        return True
    return any(
        hint in text
        for hint in ("群里说", "群里发", "去群里", "发到群", "传话", "通知群", "告诉大家")
    )


def _wants_chat_history(text: str) -> bool:
    return any(hint in text for hint in _HISTORY_HINTS)


def _history_filter(text: str) -> str | None:
    if any(key in text for key in ("私聊", "谁找你", "哪些人", "找你聊")):
        return "private"
    if any(key in text for key in ("群", "隔壁", "别的", "其他")):
        return "group"
    return None


def _history_window(text: str) -> tuple[float, float]:
    now = time.time()
    if "昨天" in text:
        return now - 48 * 3600, now - 24 * 3600
    if "刚才" in text:
        return now - 3 * 3600, now
    return now - 24 * 3600, now


async def _build_chat_digest(bot: Bot, event: MessageEvent, text: str) -> str:
    since, until = _history_window(text)
    chat_type = _history_filter(text)
    rows = memory.recent_chat(since, until, chat_type, limit=300)
    # 不把管理员自己的这轮对话混进去
    rows = [
        row
        for row in rows
        if not (row["chat_type"] == "private" and row["chat_id"] == event.user_id)
    ]
    if not rows:
        return "（最近没有查到相关聊天记录）"

    names: dict[int, str] = {}
    if any(row["chat_type"] == "group" for row in rows):
        names = await _group_name_map(bot)
    friends: dict[int, str] = {}
    if any(row["chat_type"] == "private" for row in rows):
        friends = await _friend_name_map(bot)

    def row_name(row: dict) -> str:
        if row["is_bot"]:
            return "你"
        nickname = str(row["nickname"])
        if row["chat_type"] == "private" and (not nickname or nickname.startswith("用户")):
            return friends.get(row["chat_id"], nickname)
        return nickname

    buckets: dict[tuple[str, int], list[dict]] = {}
    for row in rows:
        buckets.setdefault((row["chat_type"], row["chat_id"]), []).append(row)

    blocks: list[str] = []
    total = 0
    for (ctype, cid), items in buckets.items():
        if ctype == "group":
            title = f"【群：{names.get(cid, cid)}（{cid}）】"
        else:
            nickname = next((row_name(item) for item in items if not item["is_bot"]), str(cid))
            title = f"【私聊：{nickname}（{cid}）】"
        lines = [title]
        for item in items[-20:]:
            stamp = datetime.fromtimestamp(item["created"]).strftime("%H:%M")
            who = row_name(item)
            content = " ".join(str(item["content"]).split())[:150]
            lines.append(f"{stamp} {who}：{content}")
        block = "\n".join(lines)
        if total + len(block) > 3500:
            break
        blocks.append(block)
        total += len(block)
    return "\n\n".join(blocks) if blocks else "（最近没有查到相关聊天记录）"


def _image_urls(event: MessageEvent) -> list[str]:
    """取出消息里的图片 URL（NapCat 会带 url），供“换成这个头像”使用。"""
    urls: list[str] = []
    for seg in event.get_message():
        if seg.type != "image":
            continue
        url = str(seg.data.get("url") or seg.data.get("file") or "").strip()
        if url.startswith(("http://", "https://")) and url not in urls:
            urls.append(url)
    return urls


def _sticker_save_urls(event: MessageEvent) -> list[str]:
    urls: list[str] = []
    for seg in event.get_message():
        if seg.type not in {"image", "mface"}:
            continue
        url = str(seg.data.get("url") or "").strip()
        if url.startswith(("http://", "https://")) and url not in urls:
            urls.append(url)
    return urls


def _extract_save(text: str) -> tuple[bool, str, str]:
    save = _SAVE_RE.search(text)
    note_match = _SAVE_NOTE_RE.search(text)
    cleaned = _SAVE_RE.sub("", text)
    cleaned = _SAVE_NOTE_RE.sub("", cleaned).strip()
    if not save:
        return False, "", cleaned
    note = note_match.group(1).strip() if note_match else ""
    return True, note, cleaned


async def _save_incoming_sticker(
    event: MessageEvent,
    url: str,
    description: str,
    usage_note: str,
    context: str,
) -> int | None:
    if not settings.save_stickers:
        return None
    try:
        data, ctype = await _download_image(url)
    except Exception as exc:
        logger.debug(f"收藏表情下载失败: {exc}")
        return None
    digest = hashlib.sha256(data).hexdigest()
    existing = memory.find_sticker_by_hash(digest)
    if existing:
        return existing
    ext_map = {
        "image/jpeg": ".jpg",
        "image/jpg": ".jpg",
        "image/png": ".png",
        "image/gif": ".gif",
        "image/webp": ".webp",
    }
    ext = ext_map.get(ctype.split(";")[0].strip().lower(), ".jpg")
    _SAVED_STICKER_DIR.mkdir(parents=True, exist_ok=True)
    path = _SAVED_STICKER_DIR / f"{digest[:16]}{ext}"
    try:
        path.write_bytes(data)
        chat_type, chat_id = _chat_meta(event)
        sticker_id = memory.add_sticker(
            str(path),
            description or "收到的表情包",
            usage_note,
            f"{chat_type}:{chat_id}",
            _display_name(event),
            context,
            digest,
        )
        logger.info(f"收藏表情 #{sticker_id}: {description[:40]}")
        return sticker_id
    except Exception as exc:
        logger.warning(f"收藏表情失败: {exc}")
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        return None


def _sticker_notes(event: MessageEvent) -> list[str]:
    """把收到的 QQ 表情 / 商城表情转成文字提示，给模型接梗用。"""
    notes: list[str] = []
    for seg in event.get_message():
        if seg.type == "mface":
            summary = str(seg.data.get("summary") or "").strip()
            notes.append(f"[对方发来表情包：{summary or '未命名'}]")
        elif seg.type == "face":
            face_id = str(seg.data.get("id", ""))
            notes.append(f"[对方发来QQ表情：{_FACE_NAMES.get(face_id, face_id)}]")
    return notes


def _is_public_http_url(url: str) -> bool:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return False
    host = parsed.hostname.lower()
    if host == "localhost" or host.endswith(".local"):
        return False
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return True
    return not (
        addr.is_private
        or addr.is_loopback
        or addr.is_link_local
        or addr.is_reserved
        or addr.is_multicast
        or addr.is_unspecified
    )


async def _download_image(url: str) -> tuple[bytes, str]:
    """下载并校验图片，返回 (bytes, content-type)。"""
    if not _is_public_http_url(url):
        raise ValueError("图片地址不安全")
    async with httpx.AsyncClient(timeout=20, follow_redirects=True) as http:
        response = await http.get(url, headers={"User-Agent": "Mozilla/5.0"})
        response.raise_for_status()
        ctype = response.headers.get("content-type", "").lower()
        if not ctype.startswith("image/"):
            raise ValueError(f"不是图片: {ctype}")
        if not response.content or len(response.content) > 5 * 1024 * 1024:
            raise ValueError("图片为空或超过 5MB")
        return response.content, ctype


async def _fetch_avatar_b64(url: str) -> str:
    """下载并校验头像，转成 NapCat 需要的 base64://。"""
    data, _ = await _download_image(url)
    return base64.b64encode(data).decode("ascii")


def _parse_ocr(result) -> str:
    texts: list[str] = []

    def collect(value) -> None:
        if isinstance(value, dict):
            text = value.get("text")
            if isinstance(text, str):
                texts.append(text)
            for key in ("texts", "result"):
                if key in value:
                    collect(value[key])
        elif isinstance(value, list):
            for item in value:
                collect(item)
        elif isinstance(value, str):
            texts.append(value)

    collect(result)
    seen: list[str] = []
    for text in texts:
        text = text.strip()
        if text and text not in seen:
            seen.append(text)
    return " ".join(seen)[:300]


async def _ocr_image(bot: Bot, url: str) -> str:
    try:
        result = await bot.call_api("ocr_image", image=url)
    except Exception as exc:
        logger.debug(f"图片 OCR 不可用: {exc}")
        return ""
    return _parse_ocr(result)


async def _vision_describe(url: str) -> str:
    """如果配置了视觉模型，就用它描述图片。"""
    if not settings.vision_model or not settings.api_key:
        return ""
    data, ctype = await _download_image(url)
    data_url = f"data:{ctype};base64,{base64.b64encode(data).decode('ascii')}"
    payload = {
        "model": settings.vision_model,
        "messages": [
            {
                "role": "system",
                "content": "用一句简洁中文描述这张图片/表情包里的内容、文字和情绪，不超过60字。",
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "描述这张图"},
                    {"type": "image_url", "image_url": {"url": data_url}},
                ],
            },
        ],
        "temperature": 0.2,
        "max_tokens": 800,
        "stream": False,
    }
    async with httpx.AsyncClient(timeout=60) as http:
        response = await http.post(
            settings.api_endpoint,
            json=payload,
            headers={"Authorization": f"Bearer {settings.api_key}", "Content-Type": "application/json"},
        )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        return str(content or "").strip()[:300]


async def _describe_images(bot: Bot, images: list[str]) -> str:
    if not images:
        return ""
    if settings.vision_model:
        try:
            text = await _vision_describe(images[0])
            if text:
                return text
        except Exception as exc:
            logger.debug(f"视觉模型失败，改用 OCR: {exc}")
    if settings.image_ocr:
        try:
            return await _ocr_image(bot, images[0])
        except Exception as exc:
            logger.debug(f"OCR 失败: {exc}")
    return ""


async def _run_profile_action(bot: Bot, action: tuple[str, str]) -> bool:
    kind, value = action
    value = value.strip()
    try:
        if kind == "avatar":
            payload = await _fetch_avatar_b64(value)
            await bot.call_api("set_qq_avatar", file=f"base64://{payload}")
        elif kind == "nickname":
            if not value:
                return False
            await bot.call_api("set_qq_profile", nickname=value[:24])
        elif kind == "sign":
            if not value:
                return False
            await bot.call_api("set_self_longnick", longNick=value[:60])
        else:
            return False
        logger.info(f"已执行资料修改: {kind}")
        return True
    except Exception as exc:
        logger.warning(f"资料修改失败 {kind}: {exc}")
        return False


_PROFILE_KEYWORDS = ("头像", "昵称", "签名", "改名", "换名", "换名字", "名字换", "名字改", "资料", "名片")


def _profile_request(text: str) -> bool:
    return any(keyword in text for keyword in _PROFILE_KEYWORDS)


def _normalize_action(action: tuple[str, str], images: list[str]) -> tuple[str, str]:
    """把“last”换成刚收到的图片 URL，并从值里抠出真正的 http(s) 链接。"""
    kind, value = action
    value = value.strip().strip("\"'“”")
    if kind != "avatar":
        return kind, value
    if value.lower() in {"last", "这张", "上图", "刚才那张"} and images:
        return kind, images[-1]
    match = re.search(r"https?://[^\s\]\)）]+", value)
    if match:
        return kind, match.group(0).rstrip("。，,.;；!！?？")
    return kind, value


def _extract_action(text: str) -> tuple[tuple[str, str] | None, str]:
    match = _ACTION_RE.search(text)
    cleaned = _ACTION_RE.sub("", text)
    cleaned = re.sub(r"\[\[ACTION:[^\n]*", "", cleaned, flags=re.IGNORECASE).strip()
    if not match:
        return None, cleaned
    return (match.group(1).lower(), match.group(2).strip()), cleaned


def _extract_delegation(text: str) -> tuple[dict | None, str]:
    match = _SEND_GROUP_RE.search(text)
    cleaned = _SEND_GROUP_RE.sub("", text)
    cleaned = re.sub(r"\[\[SEND_GROUP:[^\n]*", "", cleaned).strip()
    if not match:
        return None, cleaned
    try:
        payload = json.loads(match.group(1))
    except ValueError:
        return None, cleaned
    return (payload if isinstance(payload, dict) else None), cleaned


def _sticker_segment(value: str, is_fish: bool) -> dict | None:
    value = value.strip()
    if value.startswith("#"):
        if not is_fish:
            return None
        try:
            sticker_id = int(value[1:])
        except ValueError:
            return None
        row = memory.get_sticker(sticker_id)
        if not row:
            return None
        path = Path(row["file_path"])
        if not path.exists():
            return None
        data = base64.b64encode(path.read_bytes()).decode("ascii")
        return {"type": "image", "data": {"file": f"base64://{data}"}}

    mapping = _STICKER_SETS["whale" if is_fish else "normal"]
    relative = mapping.get(value)
    if not relative:
        return None
    path = _STICKER_DIR / relative
    if not path.exists():
        return None
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return {"type": "image", "data": {"file": f"base64://{data}"}}


async def _execute_group_delegation(
    bot: Bot, event: MessageEvent, payload: dict, is_fish: bool
) -> tuple[bool, str]:
    try:
        group_id = int(payload.get("group_id"))
    except (TypeError, ValueError):
        return False, "群号不对。"
    groups = await _group_name_map(bot)
    if group_id not in groups:
        return False, "这个群我不在，发不了。"
    if not _group_allowed(group_id):
        return False, "这个群不在白名单/被拉黑，发不了。"

    message = str(payload.get("message") or "").strip()[:500]
    sticker = str(payload.get("sticker") or "").strip()
    if not message and not sticker:
        return False, "没说要发什么。"

    try:
        if message:
            await bot.call_api(
                "send_group_msg",
                group_id=group_id,
                message=[{"type": "text", "data": {"text": message}}],
            )
            memory.log_chat("group", group_id, int(bot.self_id), "你", message, is_bot=True)
            memory.append_group(group_id, int(bot.self_id), "你", message, is_bot=True)
        if sticker:
            segment = _sticker_segment(sticker, is_fish)
            if segment is None:
                return False, "没找到这个表情。"
            await bot.call_api("send_group_msg", group_id=group_id, message=[segment])
            memory.log_chat("group", group_id, int(bot.self_id), "你", "[表情包]", is_bot=True)
            memory.append_group(group_id, int(bot.self_id), "你", "[表情包]", is_bot=True)
        _last_bot_spoke[group_id] = time.time()
        return True, ""
    except Exception as exc:
        logger.warning(f"代发群消息失败: {exc}")
        return False, "没发出去，检查群号/权限。"


def _extract_sticker(text: str) -> tuple[tuple[str, str] | None, str]:
    match = _STICKER_RE.search(text)
    cleaned = _STICKER_RE.sub("", text)
    cleaned = re.sub(r"\[\[(?:STICKER|FACE):[^\n]*", "", cleaned, flags=re.IGNORECASE).strip()
    if not match:
        return None, cleaned
    return (match.group(1).upper(), match.group(2).strip()), cleaned


async def _send_sticker(bot: Bot, event: MessageEvent, sticker: tuple[str, str], is_fish: bool) -> bool:
    if not settings.stickers:
        return False
    kind, value = sticker
    value = value.strip()
    try:
        if kind == "STICKER" and value.startswith("#"):
            if not is_fish:
                return False
            try:
                sticker_id = int(value[1:])
            except ValueError:
                return False
            row = memory.get_sticker(sticker_id)
            if not row:
                return False
            path = Path(row["file_path"])
            if not path.exists():
                logger.warning(f"收藏表情文件不存在: {path}")
                return False
            data = base64.b64encode(path.read_bytes()).decode("ascii")
            result = await bot.send(event, MessageSegment.image(f"base64://{data}"))
            _remember_bot_message(event, result)
            memory.mark_sticker_used(sticker_id)
            return True

        if kind == "FACE":
            # 只发自己保存的表情包；QQ 自带的黄豆表情一律不发
            logger.debug(f"忽略 QQ 内置表情: {value}")
            return False

        mapping = _STICKER_SETS["whale" if is_fish else "normal"]
        relative = mapping.get(value)
        if not relative:
            logger.debug(f"未知表情包: {value}")
            return False
        path = _STICKER_DIR / relative
        if not path.exists():
            logger.warning(f"表情包文件不存在: {path}")
            return False
        data = base64.b64encode(path.read_bytes()).decode("ascii")
        result = await bot.send(event, MessageSegment.image(f"base64://{data}"))
        _remember_bot_message(event, result)
        return True
    except Exception as exc:
        logger.warning(f"发表情包失败 {kind}:{value}: {exc}")
        return False


def _rate_limited(user_id: int) -> bool:
    window = max(1, settings.rate_window)
    limit = settings.rate_limit
    if limit <= 0:
        return False
    now = time.time()
    bucket = _rate[user_id]
    while bucket and now - bucket[0] > window:
        bucket.popleft()
    if len(bucket) >= limit:
        return True
    bucket.append(now)
    return False


def _reveals_ai(text: str) -> bool:
    lowered = text.lower()
    if _AI_LEAK_RE.search(text):
        return True
    return any(phrase in lowered for phrase in _AI_LEAK_PHRASES)


async def _chat_guarded(messages: list[dict], user_text: str) -> str:
    """正常调用；如果回复自我暴露成 AI，就重写一次，仍不行则用真人式兜底。"""
    reply = await client.chat(messages)
    if not _reveals_ai(reply):
        return reply

    logger.warning(f"回复出戏，重写一次: {reply[:80]}")
    retry = [
        *messages,
        {"role": "assistant", "content": reply},
        {
            "role": "system",
            "content": (
                "这条回复出戏了，暴露了你不是真人。像真人一样重写一条，短一点；"
                "不要提 AI、机器人、程序、模型、代码、训练、提示词，也不要解释刚才说错什么。"
            ),
        },
    ]
    reply = await client.chat(retry)
    if not _reveals_ai(reply):
        return reply

    logger.warning(f"重写后仍出戏，使用兜底: {reply[:80]}")
    if any(key in user_text.lower() for key in ("ai", "机器人", "程序", "模型", "真人", "人吗")):
        return "你猜，猜对了我请你喝西北风。"
    return "说正事，别跑题。"


_PARTICLE_TAIL_RE = re.compile(r"(?<=[\u4e00-\u9fff])(呀|啦|哦|呢|呗|咯|哟)(?=[，。！？、…\s]|$)")
_PARTICLE_REPEAT_RE = re.compile(r"(呀|啦|哦|呢|呗|咯|哟|啊){2,}")


def _tone_down_particles(text: str) -> str:
    """压掉过量的句尾语气词和波浪号；“干嘛”“哎哟”这类词先保护起来。"""
    protected = {"干嘛": "\u0000", "哎哟": "\u0001"}
    for word, token in protected.items():
        text = text.replace(word, token)
    text = text.replace("～", "").replace("~", "")
    text = _PARTICLE_REPEAT_RE.sub(lambda match: match.group(1), text)
    text = _PARTICLE_TAIL_RE.sub("", text)
    for word, token in protected.items():
        text = text.replace(token, word)
    text = text.strip()
    if not re.search(r"[\u4e00-\u9fffA-Za-z0-9]", text):
        return ""
    return text


def _human_delay(text: str) -> float:
    """模拟“看到消息 → 打字 → 发送”的间隔；0 表示关闭。"""
    low = max(0.0, settings.reply_delay_min)
    high = max(low, settings.reply_delay_max)
    if high <= 0:
        return 0.0
    read = random.uniform(low, high)
    typing = min(len(text) / 25.0, 4.0)
    return read + typing


def _fmt_uptime(seconds: float) -> str:
    days, rem = divmod(int(seconds), 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days} 天 ")
    if hours or days:
        parts.append(f"{hours} 小时 ")
    parts.append(f"{minutes} 分 {secs} 秒")
    return "".join(parts)


_SENTENCE_RE = re.compile(r"[^。！？!?；;\n]+[。！？!?；;]?")


def _hard_split(sentence: str, limit: int) -> list[str]:
    pieces: list[str] = []
    while len(sentence) > limit:
        window = sentence[:limit]
        cut = max(window.rfind("，"), window.rfind(","), window.rfind(" "))
        cut = cut + 1 if cut >= limit // 2 else limit
        pieces.append(sentence[:cut].strip())
        sentence = sentence[cut:].strip()
    if sentence:
        pieces.append(sentence)
    return pieces


def _split_bubbles(text: str) -> list[str]:
    """像真人发消息一样分条：按句号/问号拆，再按上限合并；0 表示不分。"""
    text = text.strip()
    limit = int(settings.send_chars)
    if not text:
        return []
    if limit <= 0 or len(text) <= limit:
        return [text]

    pieces: list[str] = []
    for sentence in _SENTENCE_RE.findall(text):
        sentence = sentence.strip()
        if not sentence:
            continue
        if len(sentence) <= limit:
            pieces.append(sentence)
        else:
            pieces.extend(_hard_split(sentence, limit))

    bubbles: list[str] = []
    current = ""
    for piece in pieces:
        if current and len(current) + len(piece) > limit:
            bubbles.append(current)
            current = piece
        else:
            current += piece
    if current:
        bubbles.append(current)

    max_bubbles = max(1, int(settings.send_max_bubbles))
    if len(bubbles) > max_bubbles:
        merged: list[str] = []
        total = len(bubbles)
        for index in range(max_bubbles):
            start = index * total // max_bubbles
            end = (index + 1) * total // max_bubbles
            merged.append("".join(bubbles[start:end]))
        bubbles = merged

    return [bubble.strip() for bubble in bubbles if bubble.strip()]


async def _send(bot: Bot, event: MessageEvent, text: str, split: bool = True) -> None:
    chunks = _split_bubbles(text) if split else ([text.strip()] if text.strip() else [])
    for index, chunk in enumerate(chunks):
        if index:
            await asyncio.sleep(random.uniform(0.4, 1.2))
        message = MessageSegment.text(chunk)
        # 只给第一条加引用，分成多条时不刷屏
        if settings.quote_reply and index == 0 and isinstance(event, GroupMessageEvent):
            message = MessageSegment.reply(event.message_id) + message
        try:
            result = await bot.send(event, message)
            _remember_bot_message(event, result)
        except Exception as exc:  # 发送失败不要影响后续处理
            logger.warning(f"发送消息失败: {exc}")
            return


# ---------------------------------------------------------------- 好友/入群请求
# 广告号常用的词；命中就直接拒绝，正常朋友写“你好”“在吗”不会命中
_FRIEND_SPAM_HINTS = (
    "刷单", "刷钻", "兼职", "日结", "返利", "返佣", "贷款", "借钱", "博彩", "赌博",
    "色情", "裸聊", "约炮", "包夜", "加微信", "加vx", "加v", "加qq群", "免费领",
    "领取", "推广", "引流", "招商", "代理", "微商", "卖号", "收号", "代练", "代打",
    "充值", "中奖", "客服", "投资", "理财", "usdt", "泰达币", "挖矿", "炒币",
    "带你赚", "躺赚", "兼职群", "游戏工作室",
)
_FRIEND_GREETINGS = ("加了。", "行，加上了。", "嗯，通过了。", "加上了，有事说。", "行，加你了。")


def _admin_ids(bot: Bot) -> list[int]:
    configured = getattr(bot.config, "superusers", None) or set()
    ids: list[int] = []
    for item in configured:
        try:
            ids.append(int(item))
        except (TypeError, ValueError):
            continue
    return ids


async def _notify_admins(bot: Bot, text: str) -> None:
    """把好友请求的处理结果告诉管理员；管理员不在线也不影响主流程。"""
    for uid in _admin_ids(bot):
        try:
            await bot.call_api("send_private_msg", user_id=uid, message=text)
        except Exception as exc:
            logger.debug(f"通知管理员失败: {exc}")


def _request_comment(event: FriendRequestEvent | GroupRequestEvent) -> str:
    return re.sub(r"\s+", " ", (event.comment or "")).strip()[:60]


def _friend_spam_hint(comment: str) -> str | None:
    lowered = comment.lower()
    for hint in _FRIEND_SPAM_HINTS:
        if hint.lower() in lowered:
            return hint
    return None


def _friend_quota_left(now: float) -> bool:
    while _friend_accept_times and now - _friend_accept_times[0] > 3600:
        _friend_accept_times.popleft()
    return len(_friend_accept_times) < max(0, settings.friend_max_per_hour)


def _friend_greeting(comment: str) -> str:
    lowered = comment.lower()
    if any(word in lowered for word in ("你好", "在吗", "hi", "hello", "哈喽")):
        return "你好，加上了。"
    return random.choice(_FRIEND_GREETINGS)


async def _handle_friend_request(bot: Bot, event: FriendRequestEvent) -> None:
    comment = _request_comment(event)
    admin = _is_admin(bot, event.user_id)
    spam = _friend_spam_hint(comment)
    now = time.time()

    if not admin and not settings.friend_auto_accept:
        await _notify_admins(
            bot, f"好友请求：{event.user_id}（{comment or '没写验证消息'}）→ 自动通过已关闭，留给你处理"
        )
        return

    if admin:
        approve, reason = True, "管理员"
    elif spam:
        approve, reason = False, f"像广告（{spam}）"
    elif not _friend_quota_left(now):
        approve, reason = False, "这一小时加的人太多了"
    else:
        approve, reason = True, "看起来正常"

    remark = comment[:16] if approve and comment and not spam else ""
    try:
        await bot.call_api(
            "set_friend_add_request",
            flag=event.flag,
            approve=approve,
            remark=remark,
        )
    except Exception as exc:
        logger.warning(f"处理好友请求失败: {exc}")
        await _notify_admins(bot, f"好友请求 {event.user_id} 处理失败：{exc}")
        return

    if not approve:
        _stats["friend_no"] += 1
        logger.info(f"已拒绝好友请求 {event.user_id}：{reason}（{comment or '无验证消息'}）")
        await _notify_admins(
            bot, f"好友请求：{event.user_id}（{comment or '没写验证消息'}）→ 已拒绝（{reason}）"
        )
        return

    _stats["friend_ok"] += 1
    _friend_accept_times.append(now)
    logger.info(f"已通过好友请求 {event.user_id}：{comment or '无验证消息'}")
    await _notify_admins(
        bot, f"好友请求：{event.user_id}（{comment or '没写验证消息'}）→ 已通过"
    )

    if not settings.friend_greet:
        return
    delay = random.uniform(max(0.0, settings.reply_delay_min), max(0.0, settings.reply_delay_max))
    if delay > 0:
        await asyncio.sleep(delay)
    try:
        await bot.call_api("send_private_msg", user_id=event.user_id, message=_friend_greeting(comment))
    except Exception as exc:
        logger.debug(f"给新好友打招呼失败: {exc}")


async def _handle_group_invite(bot: Bot, event: GroupRequestEvent) -> None:
    """只自动同意管理员拉她进的群，陌生人邀请一律放着。"""
    if event.sub_type != "invite" or not settings.auto_join_group:
        return
    if not _is_admin(bot, event.user_id):
        return
    try:
        await bot.call_api(
            "set_group_add_request",
            flag=event.flag,
            sub_type="invite",
            approve=True,
        )
    except Exception as exc:
        logger.warning(f"同意入群邀请失败: {exc}")
        return
    logger.info(f"已同意管理员拉她进的群 {event.group_id}")
    await _notify_admins(bot, f"群邀请：{event.group_id}（管理员拉的）→ 已同意")


request_handler = on_request(priority=5, block=False)


@request_handler.handle()
async def _(bot: Bot, event: RequestEvent) -> None:
    if isinstance(event, FriendRequestEvent):
        await _handle_friend_request(bot, event)
    elif isinstance(event, GroupRequestEvent):
        await _handle_group_invite(bot, event)


# ---------------------------------------------------------------- 聊天入口
chat = on_message(priority=20, block=False)


@chat.handle()
async def _(bot: Bot, event: MessageEvent) -> None:
    if not isinstance(event, (GroupMessageEvent, PrivateMessageEvent)):
        return

    images = _image_urls(event)
    sticker_notes = _sticker_notes(event)
    text = _plain_text(event)
    bare_at = isinstance(event, GroupMessageEvent) and event.is_tome()
    if _should_ignore(text) and not images and not sticker_notes and not bare_at:
        return
    _log_user_event(event, text, images, sticker_notes)

    auto_reply = False
    group_context: list[dict] = []
    if isinstance(event, GroupMessageEvent):
        if not _group_allowed(event.group_id):
            _stats["ignored"] += 1
            return
        if settings.group_context > 0:
            # 先取旧上下文，再把当前这句记进去，避免同一条出现两次
            group_context = memory.group_history(event.group_id, settings.group_context)
            if text or images or sticker_notes:
                media_label = text or ("[图片]" if images else "[表情包]")
                memory.append_group(event.group_id, event.user_id, _nickname(event), media_label)
        is_at = event.is_tome()
        if settings.group_trigger == "at" and not is_at:
            return
        if settings.group_trigger == "prefix":
            text, matched = _strip_group_prefix(text)
            if not matched:
                return
        elif settings.group_trigger == "at_prefix":
            text, matched = _strip_group_prefix(text)
            if not (is_at or matched):
                return
        elif settings.group_trigger == "auto":
            text, matched = _strip_group_prefix(text)
            if not (is_at or matched):
                self_name = await _group_self_name(bot, event.group_id)
                reason = _should_interject(event, text, self_name)
                if reason is None:
                    _stats["ignored"] += 1
                    return
                auto_reply = True
                logger.debug(f"自主接话判断: {reason}")
        elif settings.group_trigger == "all":
            text, _ = _strip_group_prefix(text)
        else:  # 兜底：只响应 @
            if not is_at:
                return
    else:
        if not settings.reply_private:
            return

    text = text.strip()
    if not text and not images and not sticker_notes:
        await _send(bot, event, "在，说。", split=False)
        return

    _stats["handled"] += 1

    # 管理员不参与限流，方便调试；朋友刷屏则像真人一样回一句
    if not _is_admin(bot, event.user_id) and _rate_limited(event.user_id):
        now = time.time()
        if now - _rate_noticed.get(str(event.user_id), 0) > 30:
            _rate_noticed[str(event.user_id)] = now
            await _send(bot, event, "你刷屏呢，等我缓口气。", split=False)
        return

    key = _session_key(event)
    # ds大肥鱼只在与 AI_FISH_QQ 的好友私聊里出现；群里和其他账号一律普通人设
    is_fish = (
        isinstance(event, PrivateMessageEvent)
        and getattr(event, "sub_type", "") == "friend"
        and int(event.user_id) == settings.fish_qq
    )
    allow_profile = isinstance(event, PrivateMessageEvent) and getattr(event, "sub_type", "") == "friend"
    async with _locks[key]:
        history = memory.history(key)
        system_content = _system_prompt(is_fish)
        if isinstance(event, GroupMessageEvent) and (_profile_request(text) or images or "背景" in text):
            system_content += "\n\n现在是在群里。有人让你改头像/昵称/签名，别答应，也别执行。"
        elif allow_profile and time.time() - _last_profile_change.get(str(event.user_id), 0) < 1800:
            system_content += (
                "\n\n你半小时内刚给这个人改过资料，现在懒得再折腾；"
                "除非他理由特别有意思，不然别答应。"
            )
        if isinstance(event, PrivateMessageEvent) and _is_admin(bot, event.user_id):
            system_content += (
                "\n\n（现在私聊你的是管理员本人，是自己人；可以熟一点，"
                "但别主动提管理员、权限、指令这些词。）"
            )
        if _is_admin_private(bot, event) and _wants_group_delegation(text):
            groups = await _group_name_map(bot)
            if groups:
                lines = "\n".join(f"- {name}（{gid}）" for gid, name in list(groups.items())[:30])
                system_content += (
                    "\n\n管理员可以让你去群里办事。你们在的群：\n" + lines +
                    "\n如果管理员明确让你去某个群发消息/表情，而你判断能做，"
                    "就在回复最后另起一行写一条隐藏指令：\n"
                    '[[SEND_GROUP:{"group_id":123456,"message":"要说的话"}]] 或 '
                    '[[SEND_GROUP:{"group_id":123456,"sticker":"干饭"}]]\n'
                    "只写一条；不确定群或内容就先问，不要猜；不要发违法、骚扰、刷屏内容。"
                )
            else:
                system_content += "\n\n管理员想让你去群里办事，但现在拿不到群列表，先别执行。"
        if auto_reply:
            system_content += (
                "\n\n这句没有直接 @ 你，可能是在叫你，也可能只是随口说；"
                "接不接你自己判断，不想接就只回 [SKIP]，不要硬接，也不要解释。"
            )
        if isinstance(event, GroupMessageEvent):
            self_name = await _group_self_name(bot, event.group_id)
            if self_name:
                system_content += (
                    f"\n\n你在这个群的昵称是「{self_name}」。别人叫你{self_name}或问你身份，"
                    "就自然应一声，别用套话自我介绍。"
                )
        if _is_admin_private(bot, event) and _wants_chat_history(text):
            digest = await _build_chat_digest(bot, event, text)
            system_content += (
                "\n\n下面是你要查的其他聊天记录，只用于回答这次问题，"
                "不要当成长对话上下文，也不要主动复述无关内容：\n" + digest
            )
        image_note = await _describe_images(bot, images) if images else ""
        messages = [{"role": "system", "content": system_content}]
        if group_context:
            messages.append({"role": "system", "content": _group_prompt(group_context, include_bot=is_fish)})
        messages.extend(history)
        parts: list[str] = []
        if text:
            parts.append(text)
        if images:
            parts.append("[对方发来图片：" + " ".join(images) + "]")
            if image_note:
                parts.append(f"[图片识别：{image_note}]")
        parts.extend(sticker_notes)
        current_text = "\n".join(parts)
        current = f"{_nickname(event)}：{current_text}" if isinstance(event, GroupMessageEvent) else current_text
        messages.append({"role": "user", "content": current})

        try:
            async with _semaphore:
                reply = await _chat_guarded(messages, current_text or text)
        except ChatError as exc:
            _stats["errors"] += 1
            logger.warning(f"模型调用失败: {exc.message} | {exc.detail}")
            if _is_admin_private(bot, event):
                await _send(bot, event, f"（出错了）{exc.message}", split=False)
            else:
                await _send(bot, event, "刚卡了一下，你再说一遍？", split=False)
            return
        except Exception as exc:  # 兜底，避免插件整体崩掉
            _stats["errors"] += 1
            logger.exception(f"未预期的错误: {exc}")
            if _is_admin_private(bot, event):
                await _send(bot, event, "（出错了）内部异常，已记录日志", split=False)
            else:
                await _send(bot, event, "刚走神了，再说一遍？", split=False)
            return

        if "[SKIP]" in reply.upper():
            if auto_reply:
                _stats["skipped"] += 1
                logger.debug("自主判断：这次不接话")
                return
            reply = re.sub(r"\[SKIP\]", "", reply, flags=re.IGNORECASE).strip()
            if not reply:
                reply = "在呢。"

        delegation, reply = _extract_delegation(reply)
        if delegation:
            if not _is_admin_private(bot, event):
                delegation = None
            else:
                ok, failure = await _execute_group_delegation(bot, event, delegation, is_fish)
                if not ok:
                    reply = failure or "没发出去。"
                elif not reply:
                    reply = "发好了。"

        save_requested, save_note, reply = _extract_save(reply)
        if save_requested and settings.save_stickers:
            urls = _sticker_save_urls(event)
            if urls:
                description = image_note or (" ".join(sticker_notes) if sticker_notes else "表情包")
                saved_id = await _save_incoming_sticker(
                    event, urls[-1], description, save_note, text
                )
                if saved_id is None:
                    reply = "没存上，图打不开。"
            else:
                reply = "没图，存不了。"

        sticker, reply = _extract_sticker(reply)
        action, reply = _extract_action(reply)
        if action:
            action = _normalize_action(action, images)
            if not _profile_request(text):
                logger.warning(f"忽略没有改资料意图的动作: {action}")
                action = None
            elif action[0] == "avatar" and action[1] not in images and action[1] not in text:
                logger.warning(f"忽略来源不明的头像 URL: {action[1][:80]}")
                action = None
        if action and not allow_profile:
            action = None
            reply = "群里不折腾这个，私聊说。" if isinstance(event, GroupMessageEvent) else "这个不折腾。"
        if action:
            if await _run_profile_action(bot, action):
                _last_profile_change[str(event.user_id)] = time.time()
            else:
                reply = "没换成，晚点再说。"
        if is_fish and reply:
            reply = _tone_down_particles(reply)
        if not reply and not sticker:
            reply = "行吧。"

        memory_label = text or ("[图片]" if images else "[表情包]")
        memory.append(key, "user", memory_label)
        memory.append(key, "assistant", reply or "[表情包]")
        if isinstance(event, GroupMessageEvent):
            memory.append_group(event.group_id, int(event.self_id), "你", reply or "[表情包]", is_bot=True)
        _stats["replied"] += 1

        if reply:
            delay = _human_delay(reply)
            if delay > 0:
                logger.debug(f"模拟真人延迟 {delay:.1f}s 后发送")
                await asyncio.sleep(delay)
            await _send(bot, event, reply)
            _log_bot_event(event, reply)

        if sticker:
            await asyncio.sleep(random.uniform(0.4, 0.9))
            sent = await _send_sticker(bot, event, sticker, is_fish)
            if sent:
                _log_bot_event(event, "[表情包]" if sticker[0] == "STICKER" else "[QQ表情]")
            if not reply and not sent:
                await _send(bot, event, "行吧。", split=False)
                _log_bot_event(event, "行吧。")


# ---------------------------------------------------------------- 管理指令
help_cmd = on_command("help", aliases={"帮助", "菜单"}, priority=5, block=True)


@help_cmd.handle()
async def _(bot: Bot, event: MessageEvent) -> None:
    if not _is_admin_private(bot, event):
        return
    mode = {
        "at": "群里 @我",
        "at_prefix": f"群里 @我，或以 {settings.group_prefix} 开头",
        "prefix": f"以 {settings.group_prefix} 开头",
        "all": "群里所有消息（谨慎）",
    }.get(settings.group_trigger, "群里 @我")
    await help_cmd.finish(
        "用法：\n"
        f"· 私聊直接说话\n"
        f"· {mode}\n"
        "· /reset 清空这个会话的记忆\n"
        "· /status 查看运行状态（管理员）\n"
        f"· 模型：{settings.model}，记忆 {settings.max_history} 轮"
    )


reset_cmd = on_command("reset", aliases={"重置", "清除记忆"}, priority=5, block=True)


@reset_cmd.handle()
async def _(bot: Bot, event: MessageEvent, args: Message = CommandArg()) -> None:
    if not _is_admin_private(bot, event):
        return
    target = args.extract_plain_text().strip().lower()
    if target in {"all", "全部"}:
        count = memory.clear_all()
        group_count = memory.clear_group_all()
        chat_count = memory.clear_chat_log()
        sticker_paths = memory.clear_stickers()
        for path in sticker_paths:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError:
                pass
        await reset_cmd.finish(
            f"已清空全部记忆（{count} 个会话、{group_count} 条群聊上下文、"
            f"{chat_count} 条跨聊天记录、{len(sticker_paths)} 张收藏表情）"
        )

    key = _session_key(event)
    ok = memory.clear(key)
    await reset_cmd.finish("这个会话的记忆已清空" if ok else "这里本来就没有记忆")


status_cmd = on_command("status", aliases={"状态", "运行状态"}, priority=5, block=True)


@status_cmd.handle()
async def _(bot: Bot, event: MessageEvent) -> None:
    if not _is_admin_private(bot, event):
        return
    db_size = _db_file.stat().st_size if _db_file.exists() else 0
    whitelist = "不限" if not settings.group_whitelist else f"{len(settings.group_whitelist)} 个群"
    await status_cmd.finish(
        f"运行时长：{_fmt_uptime(time.time() - _started_at)}\n"
        f"模型：{settings.model}\n"
        f"已处理：{_stats['handled']} 条（回复 {_stats['replied']}，出错 {_stats['errors']}，自主跳过 {_stats['skipped']}）\n"
        f"好友请求：通过 {_stats['friend_ok']}，拒绝 {_stats['friend_no']}\n"
        f"记忆：{memory.sessions()} 个会话 / {memory.message_count()} 条消息\n"
        f"群聊上下文：{memory.group_count()} 条（最近 {settings.group_context} 条）\n"
        f"跨聊天记录：{memory.chat_log_count()} 条（保留 {settings.chat_log_ttl // 3600} 小时）\n"
        f"收藏表情：{memory.sticker_count()} 张\n"
        f"数据库：{_db_file.name}（{db_size / 1024:.0f} KB）\n"
        f"限流：每人 {settings.rate_limit} 次 / {settings.rate_window} 秒\n"
        f"群白名单：{whitelist}，在线 Bot：{len(nonebot.get_bots())}"
    )


@nonebot.get_driver().on_shutdown
async def _close_client() -> None:
    await client.aclose()
    memory.close()

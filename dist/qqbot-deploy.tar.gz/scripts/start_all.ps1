﻿# 一键启动：机器人 + NapCat 各开一个窗口（已在运行则跳过）
# 用法： .\start_all.bat  或  .\scripts\start_all.ps1
$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $root

function Test-Port([int]$Port) {
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $client.Connect("127.0.0.1", $Port)
        $client.Close()
        return $true
    } catch {
        return $false
    }
}

# 机器人端口
$botPort = 8080
$envPath = Join-Path $root ".env"
if (Test-Path $envPath) {
    $m = [regex]::Match((Get-Content $envPath -Raw), '(?m)^\s*PORT\s*=\s*(\d+)')
    if ($m.Success) { $botPort = [int]$m.Groups[1].Value }
}

if (Test-Port $botPort) {
    Write-Host "机器人已在运行（端口 $botPort），跳过。" -ForegroundColor Yellow
} else {
    Write-Host "启动机器人 ..." -ForegroundColor Cyan
    Start-Process -FilePath "powershell.exe" `
        -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-NoExit", "-File", "$root\run.ps1") `
        -WorkingDirectory $root
}

# NapCat
$napcat = Join-Path $root "tools\NapCat\napcat.bat"
if (-not (Test-Path $napcat)) {
    Write-Host "未找到 NapCat，先运行 .\scripts\setup_napcat.ps1" -ForegroundColor Yellow
} elseif (Test-Port 6099) {
    Write-Host "NapCat 已在运行（WebUI 6099），跳过。" -ForegroundColor Yellow
} else {
    Write-Host "启动 NapCat，请在弹出的窗口里扫码登录 ..." -ForegroundColor Cyan
    Start-Process -FilePath "cmd.exe" `
        -ArgumentList @("/k", "`"$napcat`"") `
        -WorkingDirectory (Join-Path $root "tools\NapCat")
}

Write-Host ""
Write-Host "机器人窗口和 NapCat 窗口保持打开即可；关闭窗口 = 停止对应服务。" -ForegroundColor Green

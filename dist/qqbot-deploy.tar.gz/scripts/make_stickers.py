"""生成机器人自己的表情包（不依赖外部图片）。

角色：ds大肥鱼 / 蓝色鲸鱼娘（DeepSeek 社区二创拟人），不是真的鱼。
运行： .venv\\Scripts\\python.exe scripts\\make_stickers.py
输出： assets/stickers/whale/*.png 和 assets/stickers/normal/*.png
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "assets" / "stickers"
FONT_PATH = Path("C:/Windows/Fonts/msyhbd.ttc")

WHALE = {
    "ganfan": "干饭",
    "bailan": "摆烂",
    "wuyu": "无语",
    "haoye": "好耶",
    "shui": "睡了",
    "wenhao": "问号",
}
NORMAL = {
    "wuyu": "无语",
    "wenhao": "问号",
    "haoye": "好耶",
    "bailan": "摆烂",
    "shui": "睡了",
    "zan": "赞",
}

SKIN = (255, 226, 205)
HAIR = (91, 159, 212)
HAIR_DARK = (58, 113, 164)
HAIR_LIGHT = (143, 202, 238)
DEEP = (43, 78, 110)
WHITE = (255, 255, 255)
CARD = (232, 246, 255)


def _font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FONT_PATH), size)


def _card(size: int, color: tuple[int, int, int]) -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((10, 10, size - 10, size - 10), radius=48, fill=color)
    return image, draw


def whale_sticker(caption: str, mood: str, path: Path) -> None:
    size = 360
    image, draw = _card(size, CARD)

    # 大鲸尾
    draw.polygon(
        [(246, 232), (326, 188), (338, 222), (316, 254), (338, 288), (326, 318), (246, 274)],
        fill=HAIR,
        outline=HAIR_DARK,
        width=2,
    )
    # 后面的长发
    draw.ellipse((78, 62, 282, 318), fill=HAIR_DARK)
    draw.ellipse((88, 72, 272, 308), fill=HAIR)
    # 脸
    draw.ellipse((110, 100, 250, 246), fill=SKIN)
    # 鬓发
    draw.ellipse((78, 112, 132, 300), fill=HAIR)
    draw.ellipse((228, 112, 282, 300), fill=HAIR)
    # 刘海
    draw.chord((104, 82, 256, 202), 180, 360, fill=HAIR)
    draw.chord((120, 92, 200, 172), 180, 350, fill=HAIR_LIGHT)
    # 鲸鱼头鳍
    draw.polygon([(100, 146), (72, 122), (76, 168), (104, 172)], fill=HAIR, outline=HAIR_DARK, width=2)
    draw.polygon([(260, 146), (288, 122), (284, 168), (256, 172)], fill=HAIR, outline=HAIR_DARK, width=2)
    # 呆毛
    draw.line([(178, 88), (190, 52), (210, 66)], fill=HAIR_DARK, width=4, joint="curve")
    # 女仆头饰
    draw.rounded_rectangle((126, 92, 234, 106), radius=6, fill=WHITE)
    for cx in (132, 156, 180, 204, 228):
        draw.ellipse((cx - 6, 86, cx + 6, 98), fill=WHITE)
    draw.polygon([(172, 96), (162, 82), (180, 88), (188, 80), (188, 96)], fill=HAIR_LIGHT)

    # 眼睛 / 表情
    if mood == "sleep":
        draw.arc((132, 160, 170, 194), 200, 340, fill=DEEP, width=5)
        draw.arc((190, 160, 228, 194), 200, 340, fill=DEEP, width=5)
        draw.text((290, 96), "Z", font=_font(34), fill=HAIR_DARK)
        draw.text((310, 66), "z", font=_font(24), fill=HAIR_DARK)
    else:
        for ox in (0, 58):
            draw.ellipse((132 + ox, 156, 176 + ox, 200), fill=WHITE, outline=DEEP, width=2)
            draw.ellipse((146 + ox, 168, 168 + ox, 190), fill=(70, 126, 177))
            draw.ellipse((150 + ox, 172, 160 + ox, 182), fill=(28, 55, 82))
            draw.ellipse((152 + ox, 172, 157 + ox, 177), fill=WHITE)
    # 腮红
    draw.ellipse((118, 204, 146, 220), fill=(255, 166, 176))
    draw.ellipse((214, 204, 242, 220), fill=(255, 166, 176))
    # 嘴
    if mood == "question":
        draw.arc((162, 204, 198, 234), 20, 160, fill=DEEP, width=4)
        draw.text((292, 42), "?", font=_font(50), fill=HAIR)
        draw.text((330, 20), "?", font=_font(30), fill=HAIR_LIGHT)
    elif mood == "happy":
        draw.arc((158, 204, 202, 242), 20, 160, fill=DEEP, width=4)
        draw.text((64, 52), "✦", font=_font(34), fill=(255, 196, 92))
        draw.text((286, 178), "✦", font=_font(26), fill=(255, 196, 92))
    else:
        draw.arc((160, 210, 200, 236), 15, 165, fill=DEEP, width=4)
    if mood == "speechless":
        draw.ellipse((280, 188, 304, 220), fill=(160, 214, 246))
        draw.polygon([(292, 176), (282, 200), (302, 200)], fill=(160, 214, 246))

    # 深蓝白女仆裙
    draw.polygon([(128, 244), (232, 244), (252, 306), (108, 306)], fill=HAIR_DARK)
    draw.polygon([(156, 250), (204, 250), (216, 306), (144, 306)], fill=WHITE)
    # 白饭
    if mood == "ganfan":
        draw.ellipse((274, 236, 326, 266), fill=WHITE, outline=HAIR_DARK, width=2)
        draw.arc((274, 224, 326, 252), 180, 360, fill=(250, 250, 245), width=12)
        draw.text((284, 202), "♨", font=_font(22), fill=HAIR_LIGHT)

    # 文字
    text_font = _font(42)
    bbox = draw.textbbox((0, 0), caption, font=text_font)
    tw = bbox[2] - bbox[0]
    draw.rounded_rectangle(
        (size // 2 - tw // 2 - 24, 300, size // 2 + tw // 2 + 24, 342),
        radius=18,
        fill=(255, 255, 255, 235),
    )
    draw.text((size // 2, 320), caption, font=text_font, fill=HAIR_DARK, anchor="mm")
    image.save(path)


def normal_sticker(caption: str, color: tuple[int, int, int], path: Path) -> None:
    size = 360
    image, draw = _card(size, color)
    draw.ellipse((28, 28, 82, 82), fill=(255, 255, 255, 90))
    draw.ellipse((278, 278, 330, 330), fill=(255, 255, 255, 90))
    draw.text((size // 2, size // 2 - 6), caption, font=_font(68), fill=(70, 70, 80), anchor="mm")
    image.save(path)


def main() -> None:
    whale_dir = OUT / "whale"
    normal_dir = OUT / "normal"
    whale_dir.mkdir(parents=True, exist_ok=True)
    normal_dir.mkdir(parents=True, exist_ok=True)

    moods = {
        "ganfan": "ganfan",
        "bailan": "normal",
        "wuyu": "speechless",
        "haoye": "happy",
        "shui": "sleep",
        "wenhao": "question",
    }
    for key, caption in WHALE.items():
        whale_sticker(caption, moods[key], whale_dir / f"{key}.png")

    colors = {
        "wuyu": (232, 238, 248),
        "wenhao": (255, 240, 210),
        "haoye": (220, 248, 228),
        "bailan": (245, 230, 245),
        "shui": (225, 235, 255),
        "zan": (255, 232, 220),
    }
    for key, caption in NORMAL.items():
        normal_sticker(caption, colors[key], normal_dir / f"{key}.png")

    print("whale:", ", ".join(f"{k}.png" for k in WHALE))
    print("normal:", ", ".join(f"{k}.png" for k in NORMAL))
    print("output:", OUT)


if __name__ == "__main__":
    main()
